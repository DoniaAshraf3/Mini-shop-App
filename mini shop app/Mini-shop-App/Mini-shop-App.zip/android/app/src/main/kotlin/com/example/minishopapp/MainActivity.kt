package com.example.minishopapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
